import './App.css';
import { Routes, Route } from 'react-router-dom';
import Home from './Home/home';
import Details from './component/Details/details';
import Recipe from './component/Recipe/recipe';

const App = () => {
  return (
    <>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/:details/" element={<Details />} />
        <Route path="/:details/:recipe" element={<Recipe />} />
      </Routes>
    </>
  );
};
export default App;
