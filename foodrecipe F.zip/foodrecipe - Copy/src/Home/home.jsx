import './home.css';
import Card from '../component/Card/card';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Home = () => {
  const [item, setitem] = useState([]);
  const navigate = useNavigate();

  const fetchData = async () => {
    const response = await fetch(
      'https://www.themealdb.com/api/json/v1/1/categories.php'
    );
    const data = await response.json();
    setitem(data.categories);
    console.log(item.idCategory);
  };
  const detailspage = name => {
    navigate('/' + name);
  };

  useEffect(() => {
    fetchData();
  }, []);
  return (
    <div>
      <div className="navbar">
        <div className="logo">
          <h2>F O O D R E C I P E</h2>
        </div>
        <div className="navbarcontent">
          <p>Home</p>
          <p>About</p>
          <p>Contact</p>
          <p>Sign in</p>
        </div>
      </div>

      <div className="main">
        <div className="items">
          <div className="box">
            <div className="contentmain">
              <h1>
                <span>G o o d </span>R e c i p e
              </h1>
              <h1>
                <span>G o o d </span>L i f e
              </h1>
            </div>
            <hr />
            <img src="logo1.png" alt="" />
          </div>

          {/* <div className="items"> */}
          {item.map(i => {
            return (
              // <Card id={i.idCategory} />;
              <Card
                ondetails={() => {
                  detailspage(i.strCategory);
                }}
                id={i.idCategory}
                image={i.strCategoryThumb}
                Category={i.strCategory}
                Description={i.strCategoryDescription}
              />
            );
          })}
        </div>
      </div>
      <div className="dish">
        <div className="border-box">
          <h5>
            MAKE A <span>GOOD</span> DISH
          </h5>
          <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam in
            sit qui, perferendis pariatur voluptate aliquid laborum ad adipisci,
            culpa laboriosam tempora excepturi ducimus. Impedit cum voluptatibus
            hic doloribus
            <br />
            <br />
            laudantium? Lorem ipsum dolor, sit amet consectetur adipisicing
            elit. Asperiores molestiae distinctio commodi repellat, modi totam
            consequatur molestias? Id ea voluptatem quisquam ad, est
            <br />
            <br />
          </p>
        </div>
        <div className="last">
          <h6>TASTY FOOD HEALTHY LIFE</h6>
        </div>
      </div>
      <hr />
      <footer>
        <div className="footer">
          <div className="footerlogo">
            <h2>F O O D R E C I P E</h2>
          </div>
          <div className="footercontent">
            <p>
              <i class="fa-brands fa-facebook"></i> facebook
            </p>
            <p>
              <i class="fa-brands fa-instagram"></i>Instagram
            </p>
            <p>
              <i class="fa-brands fa-twitter"></i>Twitter
            </p>
            <p>
              <i class="fa-solid fa-list"></i>Details
            </p>
          </div>
          <div className="footercontent">
            <p>
              <i class="fa-solid fa-house"></i>Home
            </p>
            <p>
              <i class="fa-brands fa-codepen"></i>About
            </p>
            <p>
              <i class="fa-solid fa-address-book"></i>Contact
            </p>
            <p>
              <i class="fa-solid fa-list"></i>Details
            </p>
          </div>

          <div className="footercontent">
            <p>
              <i class="fa-solid fa-phone"></i>Phone no
            </p>
            <p>
              <i class="fa-solid fa-magnifying-glass"></i>Class
            </p>
            <p>
              <i class="fa-solid fa-paperclip"></i>Description
            </p>
            <p>
              <i class="fa-brands fa-dropbox"></i>App
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};
export default Home;
