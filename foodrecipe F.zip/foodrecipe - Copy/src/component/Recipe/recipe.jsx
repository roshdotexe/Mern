import { useState, useEffect } from 'react';
import './recipe.css';
// import { Navigate } from 'react-router-dom';
import { useParams } from 'react-router-dom';

const Recipe = () => {
  const [item, setitem] = useState([]);
  const { recipe } = useParams();

  const fetchData = async () => {
    const response = await fetch(
      'https://www.themealdb.com/api/json/v1/1/lookup.php?i=' + recipe
    );
    const data = await response.json();
    setitem(data.meals[0]);
  };

  useEffect(() => {
    fetchData();
  }, []);
  return (
    <>
      <div className="navbar">
        <div className="logo">
          <h2>F O O D R E C I P E</h2>
        </div>
        <div className="navbarcontent">
          <p>Home</p>
          <p>About</p>
          <p>Contact</p>
          <p>Sign in</p>
        </div>
      </div>

      <div className="content3">
        <div className="grid">
          <div className="grid1">
            <h1>{item.strMeal}</h1>
            <br />
            <img src={item.strMealThumb} alt="" />
            <br />
            <br />
            <div className="incredient">
              <p>{item.strIngredient1}</p>
              <p>{item.strIngredient2}</p>
              <p>{item.strIngredient3}</p>
              <p>{item.strIngredient4}</p>
              <p>{item.strIngredient5}</p>
              <p>{item.strIngredient6}</p>
              <p>{item.strIngredient7}</p>
              <p>{item.strIngredient8}</p>
              <p>{item.strIngredient9}</p>
              <p>{item.strIngredient10}</p>
              <p>{item.strIngredient11}</p>
              <p>{item.strIngredient12}</p>
              <p>{item.strIngredient13}</p>
              <p>{item.strIngredient14}</p>
            </div>
          </div>
          <div className="grid2">
            <p>{item.strInstructions}</p>
            <h5>
              <i class="fa-brands fa-youtube"></i>
              <a href={item.strYoutube}> Click</a>
            </h5>
          </div>
        </div>
        <hr />
      </div>
      <footer>
        <div className="footer">
          <div className="footerlogo">
            <h2>F O O D R E C I P E</h2>
          </div>
          <div className="footercontent">
            <p>
              <i class="fa-brands fa-facebook"></i> facebook
            </p>
            <p>
              <i class="fa-brands fa-instagram"></i>Instagram
            </p>
            <p>
              <i class="fa-brands fa-twitter"></i>Twitter
            </p>
            <p>
              <i class="fa-solid fa-list"></i>Details
            </p>
          </div>
          <div className="footercontent">
            <p>
              <i class="fa-solid fa-house"></i>Home
            </p>
            <p>
              <i class="fa-brands fa-codepen"></i>About
            </p>
            <p>
              <i class="fa-solid fa-address-book"></i>Contact
            </p>
            <p>
              <i class="fa-solid fa-list"></i>Details
            </p>
          </div>

          <div className="footercontent">
            <p>
              <i class="fa-solid fa-phone"></i>Phone no
            </p>
            <p>
              <i class="fa-solid fa-magnifying-glass"></i>Class
            </p>
            <p>
              <i class="fa-solid fa-paperclip"></i>Description
            </p>
            <p>
              <i class="fa-brands fa-dropbox"></i>App
            </p>
          </div>
        </div>
      </footer>
    </>
  );
};
export default Recipe;
