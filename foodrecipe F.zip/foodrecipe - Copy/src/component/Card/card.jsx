import './card.css';
const Card = ({ image, Category, Description, ondetails }) => {
  return (
    <div className="card-item" onClick={ondetails}>
      {/* <img>{id> */}
      <img src={image} />
      <h3>{Category}</h3>
      <br />
      <p>{Description}</p>
    </div>
  );
};
export default Card;
