import './details.css';
import Card from '../Card/card';
import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';

const Details = () => {
  const [item, setitem] = useState([]);
  const { details } = useParams();
  const navigate1 = useNavigate();

  const fetchData = async () => {
    const response = await fetch(
      'https://www.themealdb.com/api/json/v1/1/filter.php?c=' + details
    );
    const data = await response.json();
    setitem(data.meals);
  };
  const recipepage = name => {
    navigate1('/' + details + '/' + name);
  };
  useEffect(() => {
    fetchData();
  }, []);
  return (
    <>
      <div className="navbar">
        <div className="logo">
          <h2>F O O D R E C I P E</h2>
        </div>
        <div className="navbarcontent">
          <p>Home</p>
          <p>About</p>
          <p>Contact</p>
          <p>Sign in</p>
        </div>
      </div>

      <div className="main">
        <div className="items">
          <div className="box">
            <div className="contentmain">
              <h1>
                <span>S e l e c t </span>R e c i p e
              </h1>
              <h1>
                <span>S e l e c t </span>T a s t e
              </h1>
            </div>
            <hr />
          </div>

          {/* <div className="items"> */}
          {item.map(i => {
            return (
              // <Card id={i.idCategory} />;
              <Card
                ondetails={() => {
                  recipepage(i.idMeal);
                }}
                image={i.strMealThumb}
                Category={i.strMeal}
                // Description={i.strCategoryDescription}
              />
            );
          })}
        </div>
      </div>
      <hr />
      <footer>
        <div className="footer">
          <div className="footerlogo">
            <h2>F O O D R E C I P E</h2>
          </div>
          <div className="footercontent">
            <p>
              <i class="fa-brands fa-facebook"></i> facebook
            </p>
            <p>
              <i class="fa-brands fa-instagram"></i>Instagram
            </p>
            <p>
              <i class="fa-brands fa-twitter"></i>Twitter
            </p>
            <p>
              <i class="fa-solid fa-list"></i>Details
            </p>
          </div>
          <div className="footercontent">
            <p>
              <i class="fa-solid fa-house"></i>Home
            </p>
            <p>
              <i class="fa-brands fa-codepen"></i>About
            </p>
            <p>
              <i class="fa-solid fa-address-book"></i>Contact
            </p>
            <p>
              <i class="fa-solid fa-list"></i>Details
            </p>
          </div>

          <div className="footercontent">
            <p>
              <i class="fa-solid fa-phone"></i>Phone no
            </p>
            <p>
              <i class="fa-solid fa-magnifying-glass"></i>Class
            </p>
            <p>
              <i class="fa-solid fa-paperclip"></i>Description
            </p>
            <p>
              <i class="fa-brands fa-dropbox"></i>App
            </p>
          </div>
        </div>
      </footer>
    </>
  );
};
export default Details;
